export { default } from "./SearchResults";
