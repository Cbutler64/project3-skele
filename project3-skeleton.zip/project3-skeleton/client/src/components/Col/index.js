export { default } from "./Col";
