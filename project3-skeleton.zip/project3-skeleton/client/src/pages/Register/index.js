export { default } from "./Register.js";
